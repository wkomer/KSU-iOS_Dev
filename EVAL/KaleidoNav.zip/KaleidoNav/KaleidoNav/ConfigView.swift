//
//  ConfigView.swift
//  KaleidoTab
//
//  Created by William Komer on 12/1/16.
//  Copyright © 2016 William Komer. All rights reserved.
//

import UIKit
import Darwin

class ConfigView: UIView {
    
}
