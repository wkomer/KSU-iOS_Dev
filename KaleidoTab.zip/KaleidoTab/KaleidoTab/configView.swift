//
//  configView.swift
//  KaleidoTab
//
//  Created by William Komer on 11/14/16.
//  Copyright © 2016 wkomer. All rights reserved.
//

import UIKit

class configView: UIView{
    
}
